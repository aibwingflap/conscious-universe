import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { Brain, Eye, Lightbulb, Users, BookOpen, Microscope } from 'lucide-react'
import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('introduction')

  const sections = [
    { id: 'introduction', title: 'Introduction', icon: Brain },
    { id: 'philosophical', title: 'Philosophical Perspectives', icon: Lightbulb },
    { id: 'scientific', title: 'Scientific Study', icon: Microscope },
    { id: 'models', title: 'Models of Consciousness', icon: BookOpen }
  ]

  const scrollToSection = (sectionId) => {
    setActiveSection(sectionId)
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Brain className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Consciousness</h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              {sections.map((section) => {
                const Icon = section.icon
                return (
                  <Button
                    key={section.id}
                    variant={activeSection === section.id ? "default" : "ghost"}
                    onClick={() => scrollToSection(section.id)}
                    className="flex items-center space-x-2"
                  >
                    <Icon className="h-4 w-4" />
                    <span>{section.title}</span>
                  </Button>
                )
              })}
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 space-y-12">
        {/* Hero Section */}
        <section className="text-center py-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Consciousness: A Comprehensive Overview
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Exploring the nature of awareness, experience, and the mind through philosophical, 
            scientific, and theoretical perspectives.
          </p>
          <div className="mt-8 flex justify-center space-x-4">
            <Badge variant="secondary" className="px-4 py-2">Philosophy</Badge>
            <Badge variant="secondary" className="px-4 py-2">Neuroscience</Badge>
            <Badge variant="secondary" className="px-4 py-2">Psychology</Badge>
            <Badge variant="secondary" className="px-4 py-2">Cognitive Science</Badge>
          </div>
        </section>

        {/* Introduction Section */}
        <section id="introduction" className="scroll-mt-20">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3 text-3xl">
                <Brain className="h-8 w-8 text-blue-600" />
                <span>What is Consciousness?</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-lg max-w-none">
              <p className="text-lg leading-relaxed mb-6">
                Consciousness, at its simplest, is awareness of a state or object, either internal to oneself or in one's external environment. However, its nature has led to millennia of analyses, explanations, and debate among philosophers, scientists, and theologians.
              </p>
              <p className="text-lg leading-relaxed mb-6">
                Opinions differ about what exactly needs to be studied or even considered consciousness. In some explanations, it is synonymous with the mind, and at other times, an aspect of it. In the past, it was one's "inner life", the world of introspection, of private thought, imagination, and volition. Today, it often includes any kind of cognition, experience, feeling, or perception.
              </p>
              <p className="text-lg leading-relaxed">
                It may be awareness, awareness of awareness, metacognition, or self-awareness, either continuously changing or not. The disparate range of research, notions, and speculations raises a curiosity about whether the right questions are being asked.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Philosophical Perspectives */}
        <section id="philosophical" className="scroll-mt-20">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3 text-3xl">
                <Lightbulb className="h-8 w-8 text-amber-600" />
                <span>Philosophical Perspectives</span>
              </CardTitle>
              <CardDescription className="text-lg">
                Exploring fundamental questions about the nature of mind and consciousness
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              {/* Mind-Body Problem */}
              <div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900">Mind-Body Problem</h3>
                <p className="text-lg leading-relaxed mb-4">
                  The mind-body problem is a fundamental issue in the philosophy of mind concerning the relationship between mental phenomena (such as consciousness) and physical phenomena (such as brain events). There are two main categories of solutions:
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader>
                      <CardTitle className="text-xl">Dualism</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>This view holds that the mind and body are distinct entities. René Descartes proposed that consciousness resides within an immaterial domain called <em>res cogitans</em> (the realm of thought), in contrast to <em>res extensa</em> (the realm of extension).</p>
                    </CardContent>
                  </Card>
                  <Card className="border-l-4 border-l-green-500">
                    <CardHeader>
                      <CardTitle className="text-xl">Monism</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>This view asserts that only one fundamental substance exists. Monism can take various forms, such as materialism, idealism, and neutral monism.</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <Separator />

              {/* Qualia */}
              <div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900">Qualia</h3>
                <p className="text-lg leading-relaxed">
                  Qualia refers to the subjective, qualitative properties of experiences. It's "what it's like" to have a particular sensation, such as the redness of red, the taste of wine, or the pain of a headache. Philosophers like Daniel Dennett and David Chalmers have extensively discussed qualia, particularly in relation to the "hard problem of consciousness."
                </p>
              </div>

              <Separator />

              {/* Hard Problem */}
              <div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900">The Hard Problem of Consciousness</h3>
                <p className="text-lg leading-relaxed">
                  Coined by philosopher David Chalmers, the "hard problem of consciousness" refers to the difficulty of explaining <em>why</em> and <em>how</em> physical processes in the brain give rise to subjective experience (qualia). It contrasts with the "easy problems" of consciousness, which involve explaining the mechanisms of cognitive functions like perception, learning, and memory.
                </p>
              </div>

              <Separator />

              {/* Problem of Other Minds */}
              <div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900">Problem of Other Minds</h3>
                <p className="text-lg leading-relaxed">
                  This philosophical problem concerns how we can know that other individuals (or non-human entities) possess consciousness. Since consciousness is an internal, subjective experience, we can only observe the behavior of others. This is often explored through concepts like philosophical zombies (hypothetical beings physically identical to humans but lacking conscious experience).
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Scientific Study */}
        <section id="scientific" className="scroll-mt-20">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3 text-3xl">
                <Microscope className="h-8 w-8 text-green-600" />
                <span>Scientific Study of Consciousness</span>
              </CardTitle>
              <CardDescription className="text-lg">
                Modern approaches to understanding consciousness through empirical research
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              <p className="text-lg leading-relaxed">
                For many decades, consciousness as a research topic was avoided by mainstream scientists, due to a general feeling that a phenomenon defined in subjective terms could not be properly studied using objective experimental methods. However, the field has seen significant advancements, particularly with the development of neuroscientific techniques.
              </p>

              {/* Research Methods */}
              <div className="grid md:grid-cols-3 gap-6">
                <Card className="border-t-4 border-t-blue-500">
                  <CardHeader>
                    <CardTitle className="text-xl flex items-center space-x-2">
                      <Eye className="h-5 w-5" />
                      <span>Verbal Reports</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>Experimental research often relies on verbal reports, where subjects describe their experiences. While considered a "gold standard" in some contexts, verbal reports have limitations.</p>
                  </CardContent>
                </Card>

                <Card className="border-t-4 border-t-green-500">
                  <CardHeader>
                    <CardTitle className="text-xl flex items-center space-x-2">
                      <Users className="h-5 w-5" />
                      <span>Mirror Test</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>Developed by Gordon Gallup, this test examines whether animals can differentiate between seeing themselves in a mirror versus seeing other animals.</p>
                  </CardContent>
                </Card>

                <Card className="border-t-4 border-t-purple-500">
                  <CardHeader>
                    <CardTitle className="text-xl flex items-center space-x-2">
                      <Brain className="h-5 w-5" />
                      <span>Neural Correlates</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>Studies examine the relationship between reported experiences and simultaneous brain activity using techniques like EEG and fMRI.</p>
                  </CardContent>
                </Card>
              </div>

              <Separator />

              {/* Neural Correlates Details */}
              <div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900">Neural Correlates of Consciousness (NCCs)</h3>
                <p className="text-lg leading-relaxed mb-4">
                  A major part of the scientific literature on consciousness consists of studies that examine the relationship between the experiences reported by subjects and the activity that simultaneously takes place in their brains. Key theories include:
                </p>
                <ul className="space-y-3 text-lg">
                  <li className="flex items-start space-x-3">
                    <Badge variant="outline" className="mt-1">Theory</Badge>
                    <span><strong>Oscillations in Brain Activity:</strong> Consciousness may be associated with high-frequency (gamma band) oscillations that help solve the "binding problem."</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Badge variant="outline" className="mt-1">Theory</Badge>
                    <span><strong>Prefrontal Cortex:</strong> Executive functions in the prefrontal cortex are often implicated in conscious awareness.</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Badge variant="outline" className="mt-1">Measure</Badge>
                    <span><strong>Perturbational Complexity Index (PCI):</strong> Assesses cortical response complexity to magnetic stimulation as a consciousness measure.</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Models of Consciousness */}
        <section id="models" className="scroll-mt-20">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3 text-3xl">
                <BookOpen className="h-8 w-8 text-purple-600" />
                <span>Models of Consciousness</span>
              </CardTitle>
              <CardDescription className="text-lg">
                Theoretical frameworks attempting to explain how consciousness arises
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="grid md:grid-cols-2 gap-8">
                {/* Global Workspace Theory */}
                <Card className="border-l-4 border-l-blue-500">
                  <CardHeader>
                    <CardTitle className="text-xl">Global Workspace Theory (GWT)</CardTitle>
                    <CardDescription>Proposed by Bernard Baars</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-lg leading-relaxed">
                      GWT suggests that consciousness arises from a "global workspace" in the brain, a kind of central information exchange where various specialized unconscious processors can broadcast their contents to other processors. This allows for widespread access and integration of information, leading to conscious experience.
                    </p>
                  </CardContent>
                </Card>

                {/* Integrated Information Theory */}
                <Card className="border-l-4 border-l-green-500">
                  <CardHeader>
                    <CardTitle className="text-xl">Integrated Information Theory (IIT)</CardTitle>
                    <CardDescription>Pioneered by Giulio Tononi</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-lg leading-relaxed">
                      IIT postulates that consciousness resides in the information being processed and arises once the information reaches a certain level of complexity. The theory quantifies consciousness using a measure called Phi (Φ), which represents the amount of integrated information in a system.
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg">
                <h4 className="text-xl font-semibold mb-3 text-gray-900">Key Insights from IIT</h4>
                <ul className="space-y-2 text-lg">
                  <li>• Consciousness is a fundamental property of certain physical systems</li>
                  <li>• Systems with high Phi (Φ) are considered highly conscious</li>
                  <li>• Consciousness is not exclusive to biological brains</li>
                  <li>• Could potentially exist in other complex systems</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Footer */}
        <footer className="text-center py-8 border-t">
          <p className="text-gray-600">
            This overview synthesizes current understanding of consciousness from multiple disciplines.
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Created with React and modern web technologies
          </p>
        </footer>
      </main>
    </div>
  )
}

export default App

